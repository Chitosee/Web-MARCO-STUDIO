// BloxTune server: menyajikan web + meneruskan permintaan ke Roblox Open Cloud.
// Tanpa dependensi. Butuh Node.js 18+.  Jalankan: node server.js
// API key pengguna dikirim per permintaan dan TIDAK disimpan / dicatat di server.
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000, API = 'https://apis.roblox.com', MAX = 20 * 1024 * 1024;
const TYPES = { 'audio/mpeg': '.mp3', 'audio/wav': '.wav', 'audio/ogg': '.ogg', 'audio/flac': '.flac' };
const PAGES = { '/': 'index.html', '/index.html': 'index.html', '/dashboard.html': 'dashboard.html' };
const hits = new Map();
setInterval(() => hits.clear(), 60000).unref();

const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
function readBody(req, limit) {
  return new Promise((ok, no) => {
    const c = []; let n = 0;
    req.on('data', d => { n += d.length; if (n > limit) { no(new Error('File terlalu besar (maks. 20 MB).')); req.destroy(); return; } c.push(d); });
    req.on('end', () => ok(Buffer.concat(c))); req.on('error', no);
  });
}
async function roblox(url, key, opt = {}) {
  const r = await fetch(API + url, { ...opt, headers: { 'x-api-key': key, ...(opt.headers || {}) } });
  const t = await r.text(); let j; try { j = JSON.parse(t); } catch (e) { j = { raw: t.slice(0, 300) }; }
  return { status: r.status, ok: r.ok, j };
}
const errMsg = r => (r.j && (r.j.message || r.j.error || r.j.raw)) || ('Roblox membalas ' + r.status);

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x'), p = u.pathname;
    if (req.method === 'GET' && PAGES[p]) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(path.join(__dirname, PAGES[p])).pipe(res);
    }
    if (!p.startsWith('/api/')) return json(res, 404, { error: 'Not found' });

    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    const n = (hits.get(ip) || 0) + 1; hits.set(ip, n);
    if (n > 120) return json(res, 429, { error: 'Terlalu banyak permintaan, coba lagi sebentar lagi.' });

    const key = req.headers['x-roblox-key'];
    if (!key || key.length < 20 || key.length > 2000) return json(res, 401, { error: 'API key Roblox belum diisi.' });

    // Upload audio -> Roblox (Assets API)
    if (p === '/api/upload' && req.method === 'POST') {
      const type = u.searchParams.get('type'), ext = TYPES[type];
      if (!ext) return json(res, 400, { error: 'Format harus MP3, WAV, OGG, atau FLAC.' });
      const uid = u.searchParams.get('userId'), gid = u.searchParams.get('groupId'), cid = gid || uid;
      if (!/^\d{1,15}$/.test(cid || '')) return json(res, 400, { error: 'ID pembuat harus berupa angka.' });
      const name = (u.searchParams.get('name') || 'audio').replace(/[^\w\- ]/g, '').slice(0, 50) || 'audio';
      const buf = await readBody(req, MAX);
      if (!buf.length) return json(res, 400, { error: 'File kosong.' });
      const fd = new FormData();
      fd.append('request', JSON.stringify({
        assetType: 'Audio', displayName: name, description: 'Uploaded with BloxTune',
        creationContext: { creator: gid ? { groupId: gid } : { userId: uid } }
      }));
      fd.append('fileContent', new Blob([buf], { type }), name + ext);
      const r = await roblox('/assets/v1/assets', key, { method: 'POST', body: fd });
      if (!r.ok) return json(res, r.status, { error: errMsg(r) });
      return json(res, 200, { operationId: String(r.j.path || '').replace('operations/', '') });
    }

    // Status proses upload (operation) + hasil moderasi
    if (p === '/api/operation' && req.method === 'GET') {
      const id = u.searchParams.get('id') || '';
      if (!/^[\w-]{4,80}$/.test(id)) return json(res, 400, { error: 'ID operasi tidak valid.' });
      const r = await roblox('/assets/v1/operations/' + id, key);
      if (!r.ok) return json(res, r.status, { error: errMsg(r) });
      const o = r.j, resp = o.response || {};
      return json(res, 200, {
        done: !!o.done,
        assetId: String(resp.path || '').replace('assets/', '') || null,
        state: (resp.moderationResult && resp.moderationResult.moderationState) || null,
        error: (o.error && o.error.message) || null
      });
    }

    // Cek ulang status moderasi sebuah asset
    if (p === '/api/asset' && req.method === 'GET') {
      const id = u.searchParams.get('id') || '';
      if (!/^\d{1,15}$/.test(id)) return json(res, 400, { error: 'Asset ID tidak valid.' });
      const r = await roblox('/assets/v1/assets/' + id + '?readMask=moderationResult', key);
      if (!r.ok) return json(res, r.status, { error: errMsg(r) });
      return json(res, 200, { state: (r.j.moderationResult && r.j.moderationResult.moderationState) || null });
    }

    // Izin audio massal ke Universe (Asset Permissions API)
    if (p === '/api/permissions' && req.method === 'POST') {
      const b = JSON.parse((await readBody(req, 100000)).toString() || '{}');
      const ids = [...new Set((b.assetIds || []).map(String))].filter(x => /^\d{1,15}$/.test(x)).slice(0, 50);
      const uni = String(b.universeId || '');
      if (!ids.length || !/^\d{1,15}$/.test(uni)) return json(res, 400, { error: 'Asset ID dan Universe ID harus berupa angka.' });
      const r = await roblox('/asset-permissions-api/v1/assets/permissions', key, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subjectType: 'Universe', subjectId: uni, action: 'Use', requests: ids.map(id => ({ assetId: Number(id) })) })
      });
      if (!r.ok) return json(res, r.status, { error: errMsg(r) });
      return json(res, 200, { ok: true, result: r.j });
    }
    return json(res, 404, { error: 'Not found' });
  } catch (e) {
    json(res, 500, { error: e.message || 'Kesalahan server' });
  }
}).listen(PORT, () => console.log('BloxTune berjalan di http://localhost:' + PORT));
