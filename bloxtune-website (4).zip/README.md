# BloxTune

Konverter audio Roblox + upload otomatis ke Roblox (Open Cloud) + izin audio massal.

## Jalankan
    node server.js          # butuh Node.js 18+
    # buka http://localhost:3000

## Hosting
Gunakan hosting yang bisa menjalankan Node.js (VPS, Railway, Render, Fly.io, dll).
- Start command: `node server.js`  (port dibaca dari env `PORT`)
- Pasang HTTPS (API key dikirim dari browser ke server Anda).
- Di VPS: `pm2 start server.js --name bloxtune` + Nginx/Caddy sebagai reverse proxy.
Hosting statis saja (Netlify/GitHub Pages) hanya menjalankan konverter, tidak bisa upload ke Roblox.

## API key Roblox
Buat di https://create.roblox.com/dashboard/credentials
- Izin **Assets** (read + write) untuk upload dan cek status.
- Izin **asset-permissions:write** untuk fitur Izin Audio.
- Tambahkan IP server Anda (atau 0.0.0.0/0) di daftar IP yang diizinkan.
Key disimpan di browser pengguna (localStorage) dan hanya diteruskan oleh server, tidak disimpan.
